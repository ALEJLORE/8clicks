CREATE DATABASE IF NOT EXISTS `tkwfi`;

USE `tkwfi`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `system_users`;

CREATE TABLE `system_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `age` int NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `system_users` VALUES (1,"lore",40,"alejandre.lorescajr@gmail.com"),
(4,"lore",37,"example@example.com"),
(5,"alejandre",41,"alejandreloresca39@gmail.com"),
(6,"alejandre",41,"alejandreloresca39@gmail.com"),
(7,"alej",1,"alejandreloresca39@gmail.com"),
(8,"alej",38,"alejandre.lorescajr@gmail.com"),
(9,"alej",39,"yours@gmail.com"),
(10,"alej",39,"example@example.com"),
(11,"lore",38,"example@example.com"),
(12,"alej",38,"example@example.com"),
(13,"alej",39,"alejandre.lorescajr@gmail.com"),
(14,"alej",37,"alejandre.lorescajr@gmail.com");


DROP TABLE IF EXISTS `tbl_appconfig`;

CREATE TABLE `tbl_appconfig` (
  `id` int NOT NULL AUTO_INCREMENT,
  `setting` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbl_appconfig` VALUES (1,"CompanyName","TKHOTSPOT"),
(2,"currency_code","PHP"),
(3,"language","english"),
(4,"show-logo",1),
(5,"nstyle","blue"),
(6,"timezone","Asia/Manila"),
(7,"dec_point","."),
(8,"thousands_sep",","),
(9,"rtl","0"),
(10,"address","Phase8B Package B9 L9"),
(11,"phone","09207554400"),
(12,"date_format","d M Y"),
(13,"note","Thank you..."),
(14,"country_code_phone",63),
(15,"xendit_secret_key","xnd_production_Gm9UG4xhzIfGc5zFtEZONr0YFGfd9qa4HMvtyKpHF527FYuPFUewKT25LdaV7x8"),
(16,"xendit_verification_token","v4P9dJEFux8OcB5g2HUyC2JLombIKGjYtHQkUZXiEeQsnELd"),
(17,"xendit_channel","CREDIT_CARD,PERMATA,BNI,BRI,MANDIRI,BCA,BSI,DD_BRI,DD_BCA_KLIKPAY,ALFAMART,INDOMARET,OVO,DANA,LINKAJA,SHOPEEPAY,QRIS"),
(18,"payment_gateway","xendit"),
(19,"http_proxy",""),
(20,"http_proxyauth",""),
(21,"CompanyFooter","TKSSC"),
(22,"disable_voucher","no"),
(23,"enable_balance","yes"),
(24,"allow_balance_transfer","yes"),
(25,"minimum_transfer",10),
(26,"telegram_bot","6661779585:AAEudGvMJEzVouJWVn-9imCJ8qrb35P7Yds"),
(27,"telegram_target_id",6336134031),
(28,"sms_url",""),
(29,"wa_url",""),
(30,"user_notification_expired","none"),
(31,"user_notification_reminder","none"),
(32,"user_notification_payment","none"),
(33,"tawkto",""),
(34,"radius_mode","0");


DROP TABLE IF EXISTS `tbl_bandwidth`;

CREATE TABLE `tbl_bandwidth` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name_bw` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `rate_down` int unsigned NOT NULL,
  `rate_down_unit` enum('Kbps','Mbps') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `rate_up` int unsigned NOT NULL,
  `rate_up_unit` enum('Kbps','Mbps') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbl_bandwidth` VALUES (1,"35MBPS",35,"Mbps",35,"Mbps"),
(3,"55MBPS",55,"Mbps",55,"Mbps"),
(4,"75MBPS",75,"Mbps",75,"Mbps"),
(5,"105MBPS",105,"Mbps",105,"Mbps");


DROP TABLE IF EXISTS `tbl_customers`;

CREATE TABLE `tbl_customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `pppoe_password` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fullname` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `address` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `phonenumber` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `email` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '1',
  `balance` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT 'For Money Deposit',
  `auto_renewal` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Auto renewal from balance',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbl_customers` VALUES (1,639207554400,1234,"","Alejandre A. Loresca Jr.","Caloocan City",639207554400,"alejandre.lorescajr@gmail.com","0.00",1,"2023-09-18 19:08:39","2023-10-06 23:50:47"),
(6,639153669716,1234,NULL,"Alejandre A. Loresca Jr.","Caloocan City",639153669716,"alejandre.lorescajr@gmail.com","0.00",1,"2023-10-06 20:24:34",NULL),
(7,639153669717,1234,NULL,"Alejandre A. Loresca Jr.","Caloocan City","099153669717","example@example.com","0.00",1,"2023-10-06 20:43:07",NULL);


DROP TABLE IF EXISTS `tbl_customers_meta`;

CREATE TABLE `tbl_customers_meta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `meta_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `tbl_logs`;

CREATE TABLE `tbl_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `userid` int NOT NULL,
  `ip` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbl_logs` VALUES (47,"2023-10-03 16:47:39","Admin","admin Login Successful",1,"::1"),
(48,"2023-10-06 17:37:16","Admin","admin Login Successful",1,"::1"),
(49,"2023-10-06 17:37:17","Admin","admin Login Successful",1,"::1"),
(50,"2023-10-06 18:16:08","Admin","admin Login Successful",1,"::1"),
(51,"2023-10-06 19:10:26","User","639207554400 Failed Login","0","::1"),
(52,"2023-10-06 19:10:33","User","639207554400 Failed Login","0","::1"),
(53,"2023-10-06 19:12:35","User","639207554400 Failed Login","0","::1"),
(54,"2023-10-06 19:14:06","Admin","admin Login Successful",1,"::1"),
(55,"2023-10-06 19:22:58","User","639153669716 Login Successful",5,"::1"),
(56,"2023-10-06 19:35:52","Admin","admin Login Successful",1,"::1"),
(57,"2023-10-06 20:45:00","Admin","admin Login Successful",1,"::1"),
(58,"2023-10-06 23:47:11","Admin","admin Login Successful",1,"::1"),
(59,"2023-10-06 23:50:47","User","639207554400 Login Successful",1,"::1"),
(60,"2023-10-07 00:33:00","Admin","admin Login Successful",1,"::1");


DROP TABLE IF EXISTS `tbl_message`;

CREATE TABLE `tbl_message` (
  `id` int NOT NULL AUTO_INCREMENT,
  `from_user` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `to_user` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `title` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `tbl_payment_gateway`;

CREATE TABLE `tbl_payment_gateway` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `gateway` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'xendit | midtrans',
  `gateway_trx_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `plan_id` int NOT NULL,
  `plan_name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `routers_id` int NOT NULL,
  `routers` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pg_url_payment` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `payment_method` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `payment_channel` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `pg_request` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `pg_paid_response` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `expired_date` datetime DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `paid_date` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 unpaid 2 paid 3 failed 4 canceled',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbl_payment_gateway` VALUES (1,639207554400,"xendit","650a65a9e1d9483c693f0a12",11,"TKHOTSPOT70MBPS",1,"TKHOTSPOT",10000,"https://checkout.xendit.co/v2/650a65a9e1d9483c693f0a12","","","{\"id\":\"650a65a9e1d9483c693f0a12\",\"external_id\":\"1\",\"user_id\":\"62529137806b4714df3c8548\",\"status\":\"PENDING\",\"merchant_name\":\"TKSSC\",\"merchant_profile_picture_url\":\"https:\\/\\/xnd-merchant-logos.s3.amazonaws.com\\/business\\/production\\/62529137806b4714df3c8548-1649578883482.jpeg\",\"amount\":10000,\"description\":\"TKHOTSPOT70MBPS\",\"expiry_date\":\"2023-09-21T03:23:21.709Z\",\"invoice_url\":\"https:\\/\\/checkout.xendit.co\\/v2\\/650a65a9e1d9483c693f0a12\",\"available_banks\":[],\"available_retail_outlets\":[{\"retail_outlet_name\":\"7ELEVEN\"},{\"retail_outlet_name\":\"CEBUANA\"}],\"available_ewallets\":[{\"ewallet_type\":\"PAYMAYA\"},{\"ewallet_type\":\"GRABPAY\"},{\"ewallet_type\":\"GCASH\"}],\"available_qr_codes\":[],\"available_direct_debits\":[{\"direct_debit_type\":\"DD_BPI\"},{\"direct_debit_type\":\"DD_UBP\"},{\"direct_debit_type\":\"DD_RCBC\"}],\"available_paylaters\":[],\"should_exclude_credit_card\":false,\"should_send_email\":false,\"success_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/1\\/check\",\"failure_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/1\\/check\",\"created\":\"2023-09-20T03:23:22.455Z\",\"updated\":\"2023-09-20T03:23:22.455Z\",\"currency\":\"PHP\",\"customer\":{\"mobile_number\":\"+639207554400\"},\"customer_notification_preference\":{\"invoice_created\":[\"whatsapp\",\"sms\"],\"invoice_reminder\":[\"whatsapp\",\"sms\"],\"invoice_paid\":[\"whatsapp\",\"sms\"],\"invoice_expired\":[\"whatsapp\",\"sms\"]}}","{}","2023-09-21 10:23:21","2023-09-20 10:23:18","2023-09-22 12:15:09",4),
(2,639207554400,"xendit","650d232f18b020aaa0d15b0d",2,"TKHOTSPOT",1,"TKHOTSPOT",10000,"https://checkout.xendit.co/v2/650d232f18b020aaa0d15b0d","","","{\"id\":\"650d232f18b020aaa0d15b0d\",\"external_id\":\"2\",\"user_id\":\"62529137806b4714df3c8548\",\"status\":\"PENDING\",\"merchant_name\":\"TKSSC\",\"merchant_profile_picture_url\":\"https:\\/\\/xnd-merchant-logos.s3.amazonaws.com\\/business\\/production\\/62529137806b4714df3c8548-1649578883482.jpeg\",\"amount\":10000,\"description\":\"TKHOTSPOT\",\"expiry_date\":\"2023-09-23T05:16:31.735Z\",\"invoice_url\":\"https:\\/\\/checkout.xendit.co\\/v2\\/650d232f18b020aaa0d15b0d\",\"available_banks\":[],\"available_retail_outlets\":[{\"retail_outlet_name\":\"7ELEVEN\"},{\"retail_outlet_name\":\"CEBUANA\"}],\"available_ewallets\":[{\"ewallet_type\":\"PAYMAYA\"},{\"ewallet_type\":\"GRABPAY\"},{\"ewallet_type\":\"GCASH\"}],\"available_qr_codes\":[],\"available_direct_debits\":[{\"direct_debit_type\":\"DD_BPI\"},{\"direct_debit_type\":\"DD_UBP\"},{\"direct_debit_type\":\"DD_RCBC\"}],\"available_paylaters\":[],\"should_exclude_credit_card\":false,\"should_send_email\":false,\"success_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/2\\/check\",\"failure_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/2\\/check\",\"created\":\"2023-09-22T05:16:32.292Z\",\"updated\":\"2023-09-22T05:16:32.292Z\",\"currency\":\"PHP\",\"customer\":{\"mobile_number\":\"+639207554400\"},\"customer_notification_preference\":{\"invoice_created\":[\"whatsapp\",\"sms\"],\"invoice_reminder\":[\"whatsapp\",\"sms\"],\"invoice_paid\":[\"whatsapp\",\"sms\"],\"invoice_expired\":[\"whatsapp\",\"sms\"]}}","{}","2023-09-23 12:16:31","2023-09-22 12:16:28","2023-09-22 12:16:54",4),
(3,639207554400,"xendit","650d3fa518b020d635d252e3",3,"1DAY",1,"TKHOTSPOT",10,"https://checkout.xendit.co/v2/650d3fa518b020d635d252e3","","","{\"id\":\"650d3fa518b020d635d252e3\",\"external_id\":\"3\",\"user_id\":\"62529137806b4714df3c8548\",\"status\":\"PENDING\",\"merchant_name\":\"TKSSC\",\"merchant_profile_picture_url\":\"https:\\/\\/xnd-merchant-logos.s3.amazonaws.com\\/business\\/production\\/62529137806b4714df3c8548-1649578883482.jpeg\",\"amount\":10,\"description\":\"1DAY\",\"expiry_date\":\"2023-09-23T07:17:57.590Z\",\"invoice_url\":\"https:\\/\\/checkout.xendit.co\\/v2\\/650d3fa518b020d635d252e3\",\"available_banks\":[],\"available_retail_outlets\":[{\"retail_outlet_name\":\"7ELEVEN\"},{\"retail_outlet_name\":\"CEBUANA\"}],\"available_ewallets\":[{\"ewallet_type\":\"PAYMAYA\"},{\"ewallet_type\":\"GRABPAY\"},{\"ewallet_type\":\"GCASH\"}],\"available_qr_codes\":[],\"available_direct_debits\":[{\"direct_debit_type\":\"DD_BPI\"},{\"direct_debit_type\":\"DD_UBP\"},{\"direct_debit_type\":\"DD_RCBC\"}],\"available_paylaters\":[],\"should_exclude_credit_card\":false,\"should_send_email\":false,\"success_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/3\\/check\",\"failure_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/3\\/check\",\"created\":\"2023-09-22T07:17:58.128Z\",\"updated\":\"2023-09-22T07:17:58.128Z\",\"currency\":\"PHP\",\"customer\":{\"mobile_number\":\"+639207554400\"},\"customer_notification_preference\":{\"invoice_created\":[\"whatsapp\",\"sms\"],\"invoice_reminder\":[\"whatsapp\",\"sms\"],\"invoice_paid\":[\"whatsapp\",\"sms\"],\"invoice_expired\":[\"whatsapp\",\"sms\"]}}","{}","2023-09-23 14:17:57","2023-09-22 14:17:55","2023-09-22 14:18:36",4),
(4,639207554400,"xendit","650d413ad6aa8104a1ef2fb0",3,"1DAY",1,"TKHOTSPOT",10,"https://checkout.xendit.co/v2/650d413ad6aa8104a1ef2fb0","","","{\"id\":\"650d413ad6aa8104a1ef2fb0\",\"external_id\":\"4\",\"user_id\":\"62529137806b4714df3c8548\",\"status\":\"PENDING\",\"merchant_name\":\"TKSSC\",\"merchant_profile_picture_url\":\"https:\\/\\/xnd-merchant-logos.s3.amazonaws.com\\/business\\/production\\/62529137806b4714df3c8548-1649578883482.jpeg\",\"amount\":10,\"description\":\"1DAY\",\"expiry_date\":\"2023-09-23T07:24:42.758Z\",\"invoice_url\":\"https:\\/\\/checkout.xendit.co\\/v2\\/650d413ad6aa8104a1ef2fb0\",\"available_banks\":[],\"available_retail_outlets\":[{\"retail_outlet_name\":\"7ELEVEN\"},{\"retail_outlet_name\":\"CEBUANA\"}],\"available_ewallets\":[{\"ewallet_type\":\"PAYMAYA\"},{\"ewallet_type\":\"GRABPAY\"},{\"ewallet_type\":\"GCASH\"}],\"available_qr_codes\":[],\"available_direct_debits\":[{\"direct_debit_type\":\"DD_BPI\"},{\"direct_debit_type\":\"DD_UBP\"},{\"direct_debit_type\":\"DD_RCBC\"}],\"available_paylaters\":[],\"should_exclude_credit_card\":false,\"should_send_email\":false,\"success_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/4\\/check\",\"failure_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/4\\/check\",\"created\":\"2023-09-22T07:24:43.524Z\",\"updated\":\"2023-09-22T07:24:43.524Z\",\"currency\":\"PHP\",\"customer\":{\"mobile_number\":\"+639207554400\"},\"customer_notification_preference\":{\"invoice_created\":[\"whatsapp\",\"sms\"],\"invoice_reminder\":[\"whatsapp\",\"sms\"],\"invoice_paid\":[\"whatsapp\",\"sms\"],\"invoice_expired\":[\"whatsapp\",\"sms\"]}}","{}","2023-09-23 15:24:42","2023-09-22 15:24:40","2023-09-22 15:49:51",4),
(5,639207554400,"xendit","650d531e3836ec4d5363ce19",3,"1DAY",1,"TKHOTSPOT",10,"https://checkout.xendit.co/v2/650d531e3836ec4d5363ce19","","","{\"id\":\"650d531e3836ec4d5363ce19\",\"external_id\":\"5\",\"user_id\":\"62529137806b4714df3c8548\",\"status\":\"PENDING\",\"merchant_name\":\"TKSSC\",\"merchant_profile_picture_url\":\"https:\\/\\/xnd-merchant-logos.s3.amazonaws.com\\/business\\/production\\/62529137806b4714df3c8548-1649578883482.jpeg\",\"amount\":10,\"description\":\"1DAY\",\"expiry_date\":\"2023-09-23T08:41:02.338Z\",\"invoice_url\":\"https:\\/\\/checkout.xendit.co\\/v2\\/650d531e3836ec4d5363ce19\",\"available_banks\":[],\"available_retail_outlets\":[{\"retail_outlet_name\":\"7ELEVEN\"},{\"retail_outlet_name\":\"CEBUANA\"}],\"available_ewallets\":[{\"ewallet_type\":\"PAYMAYA\"},{\"ewallet_type\":\"GRABPAY\"},{\"ewallet_type\":\"GCASH\"}],\"available_qr_codes\":[],\"available_direct_debits\":[{\"direct_debit_type\":\"DD_BPI\"},{\"direct_debit_type\":\"DD_UBP\"},{\"direct_debit_type\":\"DD_RCBC\"}],\"available_paylaters\":[],\"should_exclude_credit_card\":false,\"should_send_email\":false,\"success_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/5\\/check\",\"failure_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/5\\/check\",\"created\":\"2023-09-22T08:41:03.100Z\",\"updated\":\"2023-09-22T08:41:03.100Z\",\"currency\":\"PHP\",\"customer\":{\"mobile_number\":\"+639207554400\"},\"customer_notification_preference\":{\"invoice_created\":[\"whatsapp\",\"sms\"],\"invoice_reminder\":[\"whatsapp\",\"sms\"],\"invoice_paid\":[\"whatsapp\",\"sms\"],\"invoice_expired\":[\"whatsapp\",\"sms\"]}}","{}","2023-09-23 16:41:02","2023-09-22 16:40:59","2023-09-23 21:52:51",4),
(6,639207554400,"xendit","650eedc1053db68d72905d7c",3,"1DAY",1,"TKHOTSPOT",10,"https://checkout.xendit.co/v2/650eedc1053db68d72905d7c","","","{\"id\":\"650eedc1053db68d72905d7c\",\"external_id\":\"6\",\"user_id\":\"62529137806b4714df3c8548\",\"status\":\"PENDING\",\"merchant_name\":\"TKSSC\",\"merchant_profile_picture_url\":\"https:\\/\\/xnd-merchant-logos.s3.amazonaws.com\\/business\\/production\\/62529137806b4714df3c8548-1649578883482.jpeg\",\"amount\":10,\"description\":\"1DAY\",\"expiry_date\":\"2023-09-24T13:53:05.111Z\",\"invoice_url\":\"https:\\/\\/checkout.xendit.co\\/v2\\/650eedc1053db68d72905d7c\",\"available_banks\":[],\"available_retail_outlets\":[{\"retail_outlet_name\":\"7ELEVEN\"},{\"retail_outlet_name\":\"CEBUANA\"}],\"available_ewallets\":[{\"ewallet_type\":\"PAYMAYA\"},{\"ewallet_type\":\"GRABPAY\"},{\"ewallet_type\":\"GCASH\"}],\"available_qr_codes\":[],\"available_direct_debits\":[{\"direct_debit_type\":\"DD_BPI\"},{\"direct_debit_type\":\"DD_UBP\"},{\"direct_debit_type\":\"DD_RCBC\"}],\"available_paylaters\":[],\"should_exclude_credit_card\":false,\"should_send_email\":false,\"success_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/6\\/check\",\"failure_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/6\\/check\",\"created\":\"2023-09-23T13:53:05.855Z\",\"updated\":\"2023-09-23T13:53:05.855Z\",\"currency\":\"PHP\",\"customer\":{\"mobile_number\":\"+639207554400\"},\"customer_notification_preference\":{\"invoice_created\":[\"whatsapp\",\"sms\"],\"invoice_reminder\":[\"whatsapp\",\"sms\"],\"invoice_paid\":[\"whatsapp\",\"sms\"],\"invoice_expired\":[\"whatsapp\",\"sms\"]}}","{\"id\":\"650eedc1053db68d72905d7c\",\"external_id\":\"6\",\"user_id\":\"62529137806b4714df3c8548\",\"status\":\"EXPIRED\",\"merchant_name\":\"TKSSC\",\"merchant_profile_picture_url\":\"https:\\/\\/xnd-merchant-logos.s3.amazonaws.com\\/business\\/production\\/62529137806b4714df3c8548-1649578883482.jpeg\",\"amount\":10,\"description\":\"1DAY\",\"expiry_date\":\"2023-09-24T13:53:05.111Z\",\"invoice_url\":\"https:\\/\\/checkout.xendit.co\\/v2\\/650eedc1053db68d72905d7c\",\"available_banks\":[],\"available_retail_outlets\":[{\"retail_outlet_name\":\"7ELEVEN\"},{\"retail_outlet_name\":\"CEBUANA\"}],\"available_ewallets\":[{\"ewallet_type\":\"PAYMAYA\"},{\"ewallet_type\":\"GRABPAY\"},{\"ewallet_type\":\"GCASH\"}],\"available_qr_codes\":[],\"available_direct_debits\":[{\"direct_debit_type\":\"DD_BPI\"},{\"direct_debit_type\":\"DD_UBP\"},{\"direct_debit_type\":\"DD_RCBC\"}],\"available_paylaters\":[],\"should_exclude_credit_card\":false,\"should_send_email\":false,\"success_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/6\\/check\",\"failure_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/6\\/check\",\"created\":\"2023-09-23T13:53:05.855Z\",\"updated\":\"2023-09-24T13:53:17.384Z\",\"currency\":\"PHP\",\"customer\":{\"mobile_number\":\"+639207554400\"},\"customer_notification_preference\":{\"invoice_created\":[\"whatsapp\",\"sms\"],\"invoice_reminder\":[\"whatsapp\",\"sms\"],\"invoice_paid\":[\"whatsapp\",\"sms\"],\"invoice_expired\":[\"whatsapp\",\"sms\"]}}","2023-09-24 21:53:05","2023-09-23 21:52:59",NULL,3),
(7,639207554400,"xendit","6516a970c83bd389c6d0d7d4",3,"1DAY",1,"TKHOTSPOT",10,"https://checkout.xendit.co/v2/6516a970c83bd389c6d0d7d4","","","{\"id\":\"6516a970c83bd389c6d0d7d4\",\"external_id\":\"7\",\"user_id\":\"62529137806b4714df3c8548\",\"status\":\"PENDING\",\"merchant_name\":\"TKSSC\",\"merchant_profile_picture_url\":\"https:\\/\\/xnd-merchant-logos.s3.amazonaws.com\\/business\\/production\\/62529137806b4714df3c8548-1649578883482.jpeg\",\"amount\":10,\"description\":\"1DAY\",\"expiry_date\":\"2023-09-30T10:39:44.798Z\",\"invoice_url\":\"https:\\/\\/checkout.xendit.co\\/v2\\/6516a970c83bd389c6d0d7d4\",\"available_banks\":[],\"available_retail_outlets\":[{\"retail_outlet_name\":\"7ELEVEN\"},{\"retail_outlet_name\":\"CEBUANA\"}],\"available_ewallets\":[{\"ewallet_type\":\"PAYMAYA\"},{\"ewallet_type\":\"GRABPAY\"},{\"ewallet_type\":\"GCASH\"}],\"available_qr_codes\":[],\"available_direct_debits\":[{\"direct_debit_type\":\"DD_BPI\"},{\"direct_debit_type\":\"DD_UBP\"},{\"direct_debit_type\":\"DD_RCBC\"}],\"available_paylaters\":[],\"should_exclude_credit_card\":false,\"should_send_email\":false,\"success_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/7\\/check\",\"failure_redirect_url\":\"http:\\/\\/localhost\\/tkpisowifi\\/index.php?_route=order\\/view\\/7\\/check\",\"created\":\"2023-09-29T10:39:45.363Z\",\"updated\":\"2023-09-29T10:39:45.363Z\",\"currency\":\"PHP\",\"customer\":{\"mobile_number\":\"+639207554400\"},\"customer_notification_preference\":{\"invoice_created\":[\"whatsapp\",\"sms\"],\"invoice_reminder\":[\"whatsapp\",\"sms\"],\"invoice_paid\":[\"whatsapp\",\"sms\"],\"invoice_expired\":[\"whatsapp\",\"sms\"]}}","{}","2023-09-30 18:39:44","2023-09-29 18:39:42","2023-10-01 15:13:19",4),
(9,639207554400,"xendit","65202ce4fd41bf17cc75da0e",3,"1DAY",1,"TKHOTSPOT",10,"https://checkout.xendit.co/v2/65202ce4fd41bf17cc75da0e","","","{\"id\":\"65202ce4fd41bf17cc75da0e\",\"external_id\":\"9\",\"user_id\":\"62529137806b4714df3c8548\",\"status\":\"PENDING\",\"merchant_name\":\"TKSSC\",\"merchant_profile_picture_url\":\"https:\\/\\/xnd-merchant-logos.s3.amazonaws.com\\/business\\/production\\/62529137806b4714df3c8548-1649578883482.jpeg\",\"amount\":10,\"description\":\"1DAY\",\"expiry_date\":\"2023-10-07T15:51:00.349Z\",\"invoice_url\":\"https:\\/\\/checkout.xendit.co\\/v2\\/65202ce4fd41bf17cc75da0e\",\"available_banks\":[],\"available_retail_outlets\":[{\"retail_outlet_name\":\"7ELEVEN\"},{\"retail_outlet_name\":\"CEBUANA\"}],\"available_ewallets\":[{\"ewallet_type\":\"PAYMAYA\"},{\"ewallet_type\":\"GRABPAY\"},{\"ewallet_type\":\"GCASH\"}],\"available_qr_codes\":[],\"available_direct_debits\":[{\"direct_debit_type\":\"DD_BPI\"},{\"direct_debit_type\":\"DD_UBP\"},{\"direct_debit_type\":\"DD_RCBC\"}],\"available_paylaters\":[],\"should_exclude_credit_card\":false,\"should_send_email\":false,\"success_redirect_url\":\"http:\\/\\/localhost\\/mtk\\/_tkpisowifi\\/index.php?_route=order\\/view\\/9\\/check\",\"failure_redirect_url\":\"http:\\/\\/localhost\\/mtk\\/_tkpisowifi\\/index.php?_route=order\\/view\\/9\\/check\",\"created\":\"2023-10-06T15:51:00.876Z\",\"updated\":\"2023-10-06T15:51:00.876Z\",\"currency\":\"PHP\",\"customer\":{\"mobile_number\":\"+639207554400\"},\"customer_notification_preference\":{\"invoice_created\":[\"whatsapp\",\"sms\"],\"invoice_reminder\":[\"whatsapp\",\"sms\"],\"invoice_paid\":[\"whatsapp\",\"sms\"],\"invoice_expired\":[\"whatsapp\",\"sms\"]}}",NULL,"2023-10-07 23:51:00","2023-10-06 23:50:55",NULL,1);


DROP TABLE IF EXISTS `tbl_plans`;

CREATE TABLE `tbl_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name_plan` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_bw` int NOT NULL,
  `price` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type` enum('Hotspot','PPPOE') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `typebp` enum('Unlimited','Limited') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `limit_type` enum('Time_Limit','Data_Limit','Both_Limit') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `time_limit` int unsigned DEFAULT NULL,
  `time_unit` enum('Mins','Hrs') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `data_limit` int unsigned DEFAULT NULL,
  `data_unit` enum('MB','GB') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `validity` int NOT NULL,
  `validity_unit` enum('Mins','Hrs','Days','Months') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `shared_users` int DEFAULT NULL,
  `routers` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pool` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `pool_expired` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 disabled\r\n',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `tbl_pool`;

CREATE TABLE `tbl_pool` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pool_name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `range_ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `routers` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbl_pool` VALUES (2,"LB","192.168.4.2-192.168.4.254","LBMTK"),
(4,"NEW","192.168.7.2-192.168.7.254","RB4011");


DROP TABLE IF EXISTS `tbl_routers`;

CREATE TABLE `tbl_routers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type` enum('AP','UNO','ROUTER','RB','VENDO') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'RB',
  `ip_address` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `mac_address` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 disabled',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbl_routers` VALUES (1,"TKHOTSPOT","AP","10.5.50.1:8728","","admin","Newpa55w0rd@tkssc","",1),
(2,"TKHOTSPOT-MAIN","AP","192.168.3.247:8728","","admin","Newpa55w0rd@tkssc","",1);


DROP TABLE IF EXISTS `tbl_transactions`;

CREATE TABLE `tbl_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `plan_name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `recharged_on` date NOT NULL,
  `recharged_time` time NOT NULL DEFAULT '00:00:00',
  `expiration` date NOT NULL,
  `time` time NOT NULL,
  `method` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `routers` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type` enum('Hotspot','PPPOE') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbl_transactions` VALUES (1,"INV-57415",639207554400,"1DAY",10000,"2023-09-20","10:20:30","2023-10-20","10:20:30","Recharge - Administrator","TKHOTSPOT","Hotspot");


DROP TABLE IF EXISTS `tbl_user_recharges`;

CREATE TABLE `tbl_user_recharges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `username` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `plan_id` int NOT NULL,
  `namebp` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `recharged_on` date NOT NULL,
  `recharged_time` time NOT NULL DEFAULT '00:00:00',
  `expiration` date NOT NULL,
  `time` time NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `method` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `routers` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbl_user_recharges` VALUES (1,1,639207554400,3,"1DAY","2023-09-20","10:20:30","2023-10-20","10:20:30","on","Recharge - Administrator","TKHOTSPOT","Hotspot");


DROP TABLE IF EXISTS `tbl_users`;

CREATE TABLE `tbl_users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `fullname` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `password` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_type` enum('Admin','Sales') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` enum('Active','Inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Active',
  `last_login` datetime DEFAULT NULL,
  `creationdate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbl_users` VALUES (1,"admin","Administrator","d033e22ae348aeb5660fc2140aec35850c4da997","Admin","Active","2023-10-07 00:33:00","2014-06-23 01:43:07");


DROP TABLE IF EXISTS `tbl_voucher`;

CREATE TABLE `tbl_voucher` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` enum('Hotspot','PPPOE') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `routers` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_plan` int NOT NULL,
  `code` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbl_voucher` VALUES (1,"Hotspot","TKHOTSPOT",3,"457BBA5BE096","0","0"),
(2,"Hotspot","TKHOTSPOT",6,"E5FB64D8A34F","0","0"),
(3,"Hotspot","TKHOTSPOT",6,"F090E6AF6145","0","0"),
(4,"Hotspot","TKHOTSPOT",6,"05C309C5947A","0","0"),
(5,"Hotspot","TKHOTSPOT",6,"6B74F3FD7AE6","0","0"),
(6,"Hotspot","TKHOTSPOT",6,"B6799E98FD19","0","0"),
(7,"Hotspot","TKHOTSPOT",6,"6A0B50D8C8B6","0","0"),
(8,"Hotspot","TKHOTSPOT",6,"0794A554A466","0","0"),
(9,"Hotspot","TKHOTSPOT",6,"9CCD0B19C188","0","0"),
(10,"Hotspot","TKHOTSPOT",6,"C9E882A27AED","0","0"),
(11,"Hotspot","TKHOTSPOT",6,"259F906A1AC4","0","0");


DROP TABLE IF EXISTS `tickets`;

CREATE TABLE `tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `number` varchar(256) NOT NULL,
  `code` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=622 DEFAULT CHARSET=latin1;

INSERT INTO `tickets` VALUES (608,"demo","Caloocan City","alejandre.lorescajr@gmail.com",1234,"PFGV6J"),
(609,"demo","Caloocan City","alejandre.lorescajr@gmail.com",1234,"FUV1R4"),
(610,"admin","Caloocan City","example@example.com",1234,"QW285I"),
(611,"admin","Caloocan City","example@example.com",1234,"5A2OJ1"),
(612,"admin","Caloocan City","example@example.com",1234,"IVDAGE"),
(613,"admin","Caloocan City","example@example.com",1234,"RU5OSJ"),
(614,"admin","Caloocan City","example@example.com",1234,"JBMLQZ"),
(615,"admin","Caloocan City","example@example.com",1234,"YUO0MW"),
(616,"admin","Caloocan City","bustymangune08@gmail.com",1234,"NNQSYW"),
(617,"admin","Caloocan City","bustymangune08@gmail.com",1234,"SKHO5M"),
(618,"demo","Caloocan City","yout@h.com","09207554400","CAEQ4G"),
(619,"demo","Caloocan City","alejandre.lorescajr@gmail.com","09207554400","UDISRM"),
(620,"demo","Caloocan City","alejandre.lorescajr@gmail.com","09207554400","XJD0MU"),
(621,"demo","Caloocan City","alejandre.lorescajr@gmail.com",1234,"NACAHD");


DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `oauth_provider` enum('google','facebook','twitter','linkedin','tkhotspot') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'tkhotspot',
  `oauth_uid` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `first_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `last_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `gender` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `locale` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `picture` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fullname` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `firstname` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `lastname` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `users` VALUES (17,"google",110646431634353536869,"TK","ADVENTURES#","lorealei0107@gmail.com","","en","https://lh3.googleusercontent.com/a/ACg8ocJk1mcj0eFRfmispkl1idEGUNdmReLIcBMaNffpFDmvn1Ke=s96-c","$2y$10$c1.vDydBDIbwGh5PFUX7aeHjPHA4NufKJE59XBBo3oVi.05qIbFCC","2023-10-07 04:33:10","2023-10-07 04:36:17","TK ADVENTURES#","TK","ADVENTURES#"),
(18,"google",108518714458070845032,"Loresca","Andrei","alejandre.lorescajr@gmail.com","","en","https://lh3.googleusercontent.com/a/ACg8ocJhM1o2kdfCBp1bGRxWo1wGFRm45BxdngyzUlo27fG7w4k=s96-c","$2y$10$Cz3d4raV/2PYLi0IWvJJ2OEpLfTKuoWftLBlKK16QZLguYlCfcNda","2023-10-07 06:31:58","2023-10-07 11:32:21","Loresca Andrei","Loresca","Andrei");


SET foreign_key_checks = 1;
